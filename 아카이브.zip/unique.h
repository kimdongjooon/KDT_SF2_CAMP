#pragma once

#ifndef __UNIQUE_H__
#define __UNIQUE_H__

#include <iostream>
#include "weapon.h"
using namespace std;
class Unique: public Weapon{
    public:
        Unique();
};

#endif