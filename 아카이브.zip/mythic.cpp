#include "mythic.h"

Mythic::Mythic():Weapon("신화",5000,70,500){
    cout<<grade<<" 무기 장착!!!!"<<endl;
}
