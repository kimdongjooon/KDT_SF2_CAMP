#pragma once

#ifndef __LEGENDARY_H__
#define __LEGENDARY_H__

#include <iostream>
#include "weapon.h"
using namespace std;
class Legendary: public Weapon{
    public:
        Legendary();
};

#endif