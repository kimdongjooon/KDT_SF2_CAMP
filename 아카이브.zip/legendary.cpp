#include "legendary.h"

Legendary::Legendary():Weapon("레전더리",1000,40,300){
    cout<<grade<<" 무기 장착!!!"<<endl;
}