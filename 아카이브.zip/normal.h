#pragma once

#ifndef __NORMAL_H__
#define __NORMAL_H__

#include <iostream>
#include "weapon.h"
using namespace std;
class Normal: public Weapon{
    public:
        Normal();
};

#endif