#include "unique.h"

Unique::Unique():Weapon("유니크",30,20,50){
    cout<<grade<<" 무기 장착!!"<<endl;
}
