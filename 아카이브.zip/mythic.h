#pragma once

#ifndef __MYTHIC_H__
#define __MYTHIC_H__

#include <iostream>
#include "weapon.h"
using namespace std;
class Mythic: public Weapon{
    public:
        Mythic();
};

#endif