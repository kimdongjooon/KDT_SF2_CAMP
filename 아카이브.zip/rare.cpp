#include "rare.h"

Rare::Rare():Weapon("레어",20,10,30){
    cout<<grade<<" 무기 장착!!"<<endl;
}

