#include "normal.h"

Normal::Normal():Weapon("노말",10,0,0){
    cout<<grade<<" 무기 장착!!"<<endl;
}
