#pragma once

#ifndef __RARE_H__
#define __RARE_H__

#include <iostream>
#include "weapon.h"
using namespace std;
class Rare: public Weapon{
    public:
        Rare();
};

#endif